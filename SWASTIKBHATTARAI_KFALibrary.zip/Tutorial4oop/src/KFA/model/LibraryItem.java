package KFA.model;

// Abstract parent class containing properties common to all library items
public abstract class LibraryItem {

    private String title;
    private String isbn;
    private double price;
    private boolean available;

    // Constructor initializes common item information.
    // Every new library item is available by default.
    public LibraryItem(String title, String isbn, double price) {
        this.title = title;
        this.isbn = isbn;
        setPrice(price);
        this.available = true;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    // Prevents invalid negative prices from being stored.
    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }

        this.price = price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    // Each type of library item has its own lending period.
    public abstract int getLendingPeriodDays();
}