package KFA.model;

// Magazine inherits all common properties from LibraryItem.
public class Magazine extends LibraryItem {

    // Each magazine has its own issue number.
    private int issueNumber;

    public Magazine(
            String title,
            String isbn,
            double price,
            int issueNumber) {

        super(title, isbn, price);
        this.issueNumber = issueNumber;
    }

    public int getIssueNumber() {
        return issueNumber;
    }

    public void setIssueNumber(int issueNumber) {
        this.issueNumber = issueNumber;
    }

    // Magazines have a shorter lending period of 7 days.
    @Override
    public int getLendingPeriodDays() {
        return 7;
    }

    // Magazine deliberately does not implement Renewable
    // because magazines cannot be renewed according to library policy.

    @Override
    public String toString() {

        String status = isAvailable()
                ? "Available"
                : "Not Available";

        return String.format(
                "[%s] %s — Issue #%d — Rs %.2f (%s)",
                getIsbn(),
                getTitle(),
                issueNumber,
                getPrice(),
                status
        );
    }
}