package KFA.model;

public interface Renewable {
    void renew(int extraDays);
}

