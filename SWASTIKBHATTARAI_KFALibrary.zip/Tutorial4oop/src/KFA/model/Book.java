package KFA.model;

// Book inherits common properties from LibraryItem
// and implements Renewable because books can be renewed.
public class Book extends LibraryItem implements Renewable {

    // Static because this count is shared by all Book objects.
    private static int totalBooks = 0;

    private String author;

    // Constructor creates a book and increases the total book count.
    public Book(String title, String author, String isbn, double price) {
        super(title, isbn, price);
        this.author = author;

        // Count every Book object created.
        totalBooks++;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    // Returns the total number of Book objects created.
    public static int getTotalBooks() {
        return totalBooks;
    }

    // Books can normally be borrowed for 14 days.
    @Override
    public int getLendingPeriodDays() {
        return 14;
    }

    // Extends the lending period when a book is renewed.
    @Override
    public void renew(int extraDays) {
        System.out.println(
                "Book \"" + getTitle() +
                        "\" renewed for " + extraDays +
                        " extra days."
        );
    }

    // Gives a readable representation of a Book object.
    @Override
    public String toString() {

        String status = isAvailable()
                ? "Available"
                : "Not Available";

        return String.format(
                "[%s] %s by %s — Rs %.2f (%s)",
                getIsbn(),
                getTitle(),
                author,
                getPrice(),
                status
        );
    }
}