package KFA.model;

// DVD inherits common properties and supports renewal.
public class DVD extends LibraryItem implements Renewable {

    // Duration is specific to DVDs.
    private int durationMinutes;

    public DVD(
            String title,
            String isbn,
            double price,
            int durationMinutes) {

        super(title, isbn, price);
        this.durationMinutes = durationMinutes;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    // DVDs can normally be borrowed for 5 days.
    @Override
    public int getLendingPeriodDays() {
        return 5;
    }

    // Allows the DVD lending period to be extended.
    @Override
    public void renew(int extraDays) {
        System.out.println(
                "DVD \"" + getTitle() +
                        "\" renewed for " + extraDays +
                        " extra days."
        );
    }

    @Override
    public String toString() {

        String status = isAvailable()
                ? "Available"
                : "Not Available";

        return String.format(
                "[%s] %s — %d minutes — Rs %.2f (%s)",
                getIsbn(),
                getTitle(),
                durationMinutes,
                getPrice(),
                status
        );
    }
}