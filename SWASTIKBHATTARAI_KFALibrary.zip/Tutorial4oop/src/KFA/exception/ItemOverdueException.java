package KFA.exception;

// Checked exception used when an item is returned after its due date.
public class ItemOverdueException extends Exception {

    private int daysOverdue;

    public ItemOverdueException(String message, int daysOverdue) {
        super(message);
        this.daysOverdue = daysOverdue;
    }

    // Allows the program to retrieve the number of overdue days.
    public int getDaysOverdue() {
        return daysOverdue;
    }
}
