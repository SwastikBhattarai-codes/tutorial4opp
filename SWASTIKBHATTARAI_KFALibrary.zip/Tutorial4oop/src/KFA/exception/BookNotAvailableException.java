package KFA.exception;

// Checked exception used when a user tries to borrow an unavailable item.
public class BookNotAvailableException extends Exception {

    public BookNotAvailableException(String message) {
        super(message);
    }
}