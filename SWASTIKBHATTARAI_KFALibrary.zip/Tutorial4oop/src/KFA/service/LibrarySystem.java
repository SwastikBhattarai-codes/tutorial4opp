package KFA.service;

import KFA.model.LibraryItem;
import KFA.exception.BookNotAvailableException;
import KFA.exception.ItemOverdueException;

// Handles borrowing and returning operations for library items.
public class LibrarySystem {

    // Attempts to borrow an item from the library.
    public void borrowItem(LibraryItem item)
            throws BookNotAvailableException {

        // An unavailable item cannot be borrowed again.
        if (!item.isAvailable()) {

            throw new BookNotAvailableException("Sorry, \"" + item.getTitle() + "\" is currently unavailable.");
        }

        // Mark the item as unavailable after successful borrowing.
        item.setAvailable(false);

        System.out.println(
                "\"" + item.getTitle() + "\" borrowed successfully."
        );
    }

    // Attempts to return an item to the library.
    public void returnItem(LibraryItem item, int daysLate)
            throws ItemOverdueException {

        // A positive daysLate value means the item was returned late.
        if (daysLate > 0) {

            throw new ItemOverdueException("\"" + item.getTitle() +"\" is " + daysLate + " day(s) overdue.", daysLate);
        }

        // If the item is returned on time, make it available again.
        item.setAvailable(true);

        System.out.println("\"" + item.getTitle() + "\" returned successfully.");
    }
}
