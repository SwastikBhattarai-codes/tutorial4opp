import KFA.model.Book;
import KFA.model.DVD;
import KFA.model.Magazine;
import KFA.model.LibraryItem;
import KFA.service.LibrarySystem;
import KFA.exception.BookNotAvailableException;
import KFA.exception.ItemOverdueException;

import java.util.Random;

public class Main {

    public static void main(String[] args) {

        System.out.println("========== SECTION A ==========");

        // Create four Book objects using the parameterised constructor.
        Book book1 = new Book(
                "Clean Code",
                "Robert Martin",
                "B001",
                850.00
        );

        Book book2 = new Book(
                "Effective Java",
                "Joshua Bloch",
                "B002",
                1200.00
        );

        Book book3 = new Book(
                "Head First Java",
                "Kathy Sierra",
                "B003",
                950.00
        );

        Book book4 = new Book(
                "Java: The Complete Reference",
                "Herbert Schildt",
                "B004",
                1100.00
        );

        // Store the books in an array so they can be processed using a loop.
        Book[] books = {
                book1,
                book2,
                book3,
                book4
        };

        // Print each book using its overridden toString() method.
        for (Book book : books) {
            System.out.println(book);
        }

        // Static method gives the total number of Book objects created.
        System.out.println(
                "Total books: " + Book.getTotalBooks()
        );

        System.out.println("\n========== SECTION B ==========");

        // Create different types of library items.
        Magazine magazine = new Magazine(
                "Tech Monthly",
                "M001",
                450.00,
                25
        );

        DVD dvd = new DVD(
                "Java Programming Course",
                "D001",
                750.00,
                120
        );

        // Parent-class references can store objects of different subclasses.
        LibraryItem[] items = {
                book1,
                book2,
                magazine,
                dvd
        };

        // Java automatically calls the correct overridden method
        // depending on the actual object stored in the array.
        for (LibraryItem item : items) {

            System.out.println(item);

            System.out.println(
                    "Lending period: " + item.getLendingPeriodDays() + " days"
            );

            System.out.println();
        }
                System.out.println("========== SECTION C ==========");

        LibrarySystem library = new LibrarySystem();
        try {

            library.borrowItem(book1);

        } catch (BookNotAvailableException e) {

            // Display a friendly message instead of a stack trace.
            System.out.println(
                    "Borrow error: " + e.getMessage()
            );

        } finally {

            // This block executes whether an exception occurs or not.
            System.out.println(
                    "Transaction processed for: " + book1.getTitle()
            );
        }
                try {

            // book1 is still unavailable because it was borrowed above.
            library.borrowItem(book1);

        } catch (BookNotAvailableException e) {

            System.out.println(
                    "Borrow error: " + e.getMessage()
            );

        } finally {

            System.out.println(
                    "Transaction processed for: " +
                            book1.getTitle()
            );
        }

        try {

            // daysLate = 0 means the item is returned on time.
            library.returnItem(book1, 0);

        } catch (ItemOverdueException e) {

            System.out.println(
                    "Return error: " + e.getMessage()
            );

        } finally {

            System.out.println(
                    "Transaction processed for: " +
                            book1.getTitle()
            );
        }




        try {

            // Positive daysLate causes ItemOverdueException.
            library.returnItem(book1, 3);

        } catch (ItemOverdueException e) {

            System.out.println(
                    "Return error: " + e.getMessage()
            );

            System.out.println(
                    "Days overdue: " +e.getDaysOverdue()
            );

        } finally {

            System.out.println(
                    "Transaction processed for: " +book1.getTitle()
            );
        }
        System.out.println("\n========== SECTION D1 ==========");

        String memberName = "Aarav Shrestha";

        // Generate an ID using the first and last names.
        String memberId = generateMemberId(memberName);

        System.out.println(
                "Member name: " + memberName
        );

        System.out.println(
                "Member ID: " + memberId
        );
        System.out.println("\n========== SECTION D2 ==========");

        // Test valid and invalid ISBN values.
        String[] isbnTests = {
                "9780132350884",  // Valid
                "9780134685991",  // Valid
                "978013235088",   // Invalid: 12 characters
                "97801323A0884",  // Invalid: contains a letter
                "0780132350884"   // Invalid: starts with 0
        };

        for (String isbn : isbnTests) {

            System.out.println(
                    isbn + " -> " +
                            isValidIsbn(isbn)
            );
        }

        System.out.println("\n========== SECTION D3 ==========");

        // Generate a complete catalogue report.
        System.out.println(
                buildCatalogueReport(items)
        );

        // Generate a filtered report using the keyword "java".
        System.out.println(
                "\n--- Search results for 'java' ---"
        );

        System.out.println(
                buildCatalogueReport(items, "java")
        );
    }
    public static String generateMemberId(String fullName) {

        // Remove unnecessary spaces from the beginning and end.
        fullName = fullName.trim();

        // Split the full name into separate words.
        String[] names = fullName.split(" ");

        // The first word is treated as the first name.
        String firstName = names[0];

        String firstPart;

        // Take the first three letters when possible.
        if (firstName.length() >= 3) {

            firstPart =
                    firstName.substring(0, 3).toUpperCase();

        } else {

            // If the name has fewer than three letters,
            // use the complete first name.
            firstPart =
                    firstName.toUpperCase();
        }

        String lastPart = "";

        // Check whether a last name exists.
        if (names.length >= 2) {

            // The final word is treated as the last name.
            String lastName =
                    names[names.length - 1];

            // Take the first two letters of the last name.
            if (lastName.length() >= 2) {

                lastPart =
                        lastName.substring(0, 2).toUpperCase();

            } else {

                lastPart =
                        lastName.toUpperCase();
            }

        } else {

            // For a single-word name, "XX" represents the missing last name.
            lastPart = "XX";
        }

        // Generate a random three-digit number from 100 to 999.
        Random random = new Random();

        int number =
                100 + random.nextInt(900);

        // Combine the name parts and random number to create the ID.
        return firstPart + lastPart + number;
    }

    public static boolean isValidIsbn(String isbn) {

        // Reject null input.
        if (isbn == null) {
            return false;
        }

        // Rule 1: ISBN must contain exactly 13 characters.
        if (isbn.length() != 13) {
            return false;
        }

        // Rule 2: ISBN must not start with the digit 0.
        if (isbn.charAt(0) == '0') {
            return false;
        }

        // Rule 3: Check every character to ensure it is a digit.
        for (int i = 0; i < isbn.length(); i++) {

            char c = isbn.charAt(i);

            // Characters outside 0-9 are not valid digits.
            if (c < '0' || c > '9') {
                return false;
            }
        }

        // All validation rules have passed.
        return true;
    }

    public static String buildCatalogueReport(
            LibraryItem[] items) {

        // StringBuilder efficiently builds a large string.
        StringBuilder report =
                new StringBuilder();

        report.append(
                "========== CATALOGUE ==========\n"
        );

        // Add every library item to the report.
        for (LibraryItem item : items) {

            report.append("Title: ")
                    .append(item.getTitle())
                    .append("\n");

            report.append("Availability: ")
                    .append(
                            item.isAvailable()
                                    ? "Available"
                                    : "Not Available"
                    )
                    .append("\n");

            report.append(
                    "-------------------------------\n"
            );
        }

        return report.toString();
    }
    public static String buildCatalogueReport(
            LibraryItem[] items,
            String keyword) {

        StringBuilder report =
                new StringBuilder();

        // Convert the keyword to lowercase so the search
        // becomes case-insensitive.
        String searchWord =
                keyword.toLowerCase();

        report.append(
                "========== SEARCH RESULTS ==========\n"
        );

        // Search directly through the original array.
        // No second array is created.
        for (LibraryItem item : items) {

            // Convert the title to lowercase and check
            // whether it contains the search keyword.
            if (item.getTitle()
                    .toLowerCase()
                    .contains(searchWord)) {

                report.append("Title: ")
                        .append(item.getTitle())
                        .append("\n");

                report.append("Availability: ")
                        .append(
                                item.isAvailable()
                                        ? "Available"
                                        : "Not Available"
                        )
                        .append("\n");

                report.append(
                        "-------------------------------\n"
                );
            }
        }

        return report.toString();
    }
}